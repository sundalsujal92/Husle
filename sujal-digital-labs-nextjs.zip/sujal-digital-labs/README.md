# Sujal Digital Labs — Website

A responsive multi-page Next.js website for Sujal Digital Labs, styled with Tailwind CSS v4.

## Included
- Home page
- Services page
- Portfolio / work page
- About page
- Contact page
- Responsive navigation
- SEO metadata and Open Graph defaults
- Contact form that prepares an email using the visitor's email application (no backend or data storage)
- Premium dark navy / electric blue / violet visual system

## Requirements
- Node.js 20.9 or newer
- npm

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

## Before launch
1. Confirm domain ownership and configure DNS for your hosting provider.
2. Replace `hello@sujaldigitallabs.com` if you choose another mailbox.
3. Configure a real form backend (for example, a secure API route plus a transactional email provider) if you want enquiries stored or sent server-side. The current form opens the visitor's mail application.
4. Add real screenshots and verified project details to the portfolio.
5. Add privacy policy, terms, cookie notice if applicable, and business/legal details.
6. Review all copy, service pricing, and claims before publishing.
7. Verify metadata, favicon, social preview image and analytics configuration.

## Deploy to Vercel
1. Push this project to a Git repository.
2. Import the repository into Vercel.
3. Use the default Next.js build settings.
4. Add `sujaldigitallabs.com` in Vercel project settings.
5. Apply the DNS records Vercel provides at your domain registrar.
6. Wait for DNS verification and HTTPS provisioning.

The domain is not registered or connected by this source package.
