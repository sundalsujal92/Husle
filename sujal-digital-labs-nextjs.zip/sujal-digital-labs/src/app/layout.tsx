import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  metadataBase: new URL("https://sujaldigitallabs.com"),
  title: {
    default: "Sujal Digital Labs | Build. Automate. Scale.",
    template: "%s | Sujal Digital Labs",
  },
  description:
    "Sujal Digital Labs builds modern websites, custom web applications and practical AI-powered workflows for ambitious businesses.",
  openGraph: {
    title: "Sujal Digital Labs",
    description: "Build. Automate. Scale.",
    url: "https://sujaldigitallabs.com",
    siteName: "Sujal Digital Labs",
    type: "website",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} antialiased`}>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
