import Link from "next/link";
import { ArrowRight, ArrowUpRight, Bot, Braces, Cloud, Layers3, Workflow, Check, Sparkles } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

const services = [
  { icon: Braces, title: "Web development", text: "Fast, thoughtful websites and custom applications designed around the way your business works." },
  { icon: Bot, title: "AI automation", text: "Practical AI assistants and connected workflows that reduce repetitive work and improve response times." },
  { icon: Cloud, title: "Cloud & DevOps", text: "Reliable deployment foundations, infrastructure configuration and delivery workflows." },
  { icon: Workflow, title: "Business systems", text: "Dashboards, portals and integrations that bring important business processes together." },
];

const steps = [
  ["01", "Discover", "We understand your goals, users and current bottlenecks."],
  ["02", "Design", "We map the experience and agree on a clear scope."],
  ["03", "Build", "We develop, test and refine the solution with you."],
  ["04", "Launch", "We deploy, hand over and support your next steps."],
];

export default function HomePage() {
  return (
    <>
      <section className="relative isolate overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 -z-10 grid-bg opacity-70" />
        <div className="glow absolute -right-40 -top-28 -z-10 h-[650px] w-[850px]" />
        <div className="container grid min-h-[690px] items-center gap-14 py-24 lg:grid-cols-[1.05fr_.95fr] lg:py-28">
          <div>
            <span className="eyebrow"><Sparkles size={13}/> Digital innovation partner</span>
            <h1 className="mt-7 max-w-3xl text-5xl font-semibold leading-[1.08] tracking-[-.055em] sm:text-6xl lg:text-[68px]">
              We build digital experiences that <span className="gradient-text">move business forward.</span>
            </h1>
            <p className="mt-7 max-w-xl text-base leading-8 text-slate-400 sm:text-lg">From high-performance websites to intelligent automation, we help ambitious businesses simplify operations, connect with customers and scale with confidence.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/contact" className="btn-primary">Discuss your project <ArrowUpRight size={17}/></Link>
              <Link href="/work" className="btn-secondary">Explore our work <ArrowRight size={16}/></Link>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-7 gap-y-3 text-xs font-medium text-slate-400">
              <span className="flex items-center gap-2"><Check size={14} className="text-blue-300"/> Thoughtful engineering</span>
              <span className="flex items-center gap-2"><Check size={14} className="text-blue-300"/> Clear communication</span>
              <span className="flex items-center gap-2"><Check size={14} className="text-blue-300"/> Built for your goals</span>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-[520px]">
            <div className="absolute inset-10 rounded-full bg-blue-500/20 blur-[90px]"/>
            <div className="panel relative overflow-hidden p-5 shadow-2xl shadow-blue-950/30 sm:p-7">
              <div className="flex items-center justify-between border-b border-white/10 pb-5">
                <div><p className="text-xs text-slate-500">Sujal Digital Labs</p><p className="mt-1 text-sm font-semibold">Digital systems, made useful.</p></div>
                <span className="rounded-full border border-blue-300/20 bg-blue-400/10 px-3 py-1 text-[10px] font-semibold tracking-wider text-blue-200">SDL / STUDIO</span>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-blue-300/15 bg-blue-400/[.07] p-4">
                  <Braces className="text-blue-300" size={22}/><p className="mt-8 text-sm font-semibold">Digital products</p><p className="mt-1 text-xs leading-5 text-slate-400">Websites & applications</p>
                </div>
                <div className="rounded-2xl border border-violet-300/15 bg-violet-400/[.07] p-4">
                  <Bot className="text-violet-300" size={22}/><p className="mt-8 text-sm font-semibold">Intelligent workflows</p><p className="mt-1 text-xs leading-5 text-slate-400">AI & automation</p>
                </div>
                <div className="col-span-2 rounded-2xl border border-white/10 bg-[#0a1221] p-5">
                  <div className="flex items-center justify-between"><p className="text-xs font-semibold text-slate-300">A clearer path from idea to impact</p><Layers3 size={17} className="text-blue-300"/></div>
                  <div className="mt-5 grid grid-cols-4 gap-2">
                    {["Discover","Design","Build","Launch"].map((s,i)=><div key={s} className="text-center"><div className="mx-auto grid h-9 w-9 place-items-center rounded-xl border border-blue-300/20 bg-blue-400/10 text-xs font-bold text-blue-200">{`0${i+1}`}</div><p className="mt-2 text-[10px] text-slate-400">{s}</p></div>)}
                  </div>
                </div>
              </div>
              <p className="mt-5 text-center text-[10px] tracking-[.2em] text-slate-500">BUILD. AUTOMATE. SCALE.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHeading eyebrow="What we do" title="Technology that solves real business problems." description="We bring strategy, design and engineering together to create digital tools that are useful, dependable and ready to grow." centered/>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {services.map(({icon: Icon,title,text})=><div key={title} className="panel card-hover p-6"><div className="grid h-11 w-11 place-items-center rounded-xl border border-blue-300/20 bg-blue-400/10 text-blue-200"><Icon size={21}/></div><h3 className="mt-6 text-lg font-semibold">{title}</h3><p className="mt-3 text-sm leading-7 text-slate-400">{text}</p><Link href="/services" className="mt-6 inline-flex items-center gap-2 text-xs font-semibold text-blue-300 hover:text-white">Explore service <ArrowUpRight size={14}/></Link></div>)}
          </div>
        </div>
      </section>

      <section className="section border-y border-white/10 bg-[#0b1220]">
        <div className="container grid items-center gap-14 lg:grid-cols-[.9fr_1.1fr]">
          <div><SectionHeading eyebrow="Why Sujal Digital Labs" title="A hands-on partner from first idea to launch." description="Good technology should make work simpler, not add another layer of complexity. We focus on understanding the problem before choosing the tools."/><Link href="/about" className="btn-secondary">Get to know us <ArrowUpRight size={16}/></Link></div>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              ["Business-first thinking","Start with your goals, users and practical constraints."],
              ["Modern engineering","Choose reliable tools that fit the job, not trends for their own sake."],
              ["Clear collaboration","Know what is happening, what comes next and what decisions are needed."],
              ["Built to evolve","Create a foundation that can adapt as your business grows."],
            ].map(([title,text],i)=><div key={title} className="rounded-2xl border border-white/10 bg-white/[.025] p-6"><span className="text-xs font-bold tracking-widest text-blue-300">0{i+1}</span><h3 className="mt-5 font-semibold">{title}</h3><p className="mt-2 text-sm leading-7 text-slate-400">{text}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHeading eyebrow="Selected work" title="A foundation built through real projects." description="Explore a sample of our product thinking and engineering. Demonstration concepts are identified clearly, so you know what is live work and what is in development."/>
          <div className="grid gap-5 md:grid-cols-2">
            <div className="panel overflow-hidden">
              <div className="grid-bg flex h-52 items-center justify-center bg-[#101c33] p-8"><div className="w-full max-w-sm rounded-xl border border-blue-200/20 bg-[#0a1221] p-5 shadow-2xl"><div className="flex justify-between"><span className="text-xs font-bold">JOBMARKET</span><span className="text-[10px] text-blue-300">CAREERS PLATFORM</span></div><div className="mt-7 h-3 w-2/3 rounded bg-slate-600/70"/><div className="mt-3 h-2 w-1/2 rounded bg-slate-700"/><div className="mt-6 grid grid-cols-3 gap-2">{[1,2,3].map(n=><div key={n} className="h-12 rounded-lg border border-white/10 bg-white/5"/>)}</div></div></div>
              <div className="p-7"><span className="eyebrow">Existing project</span><h3 className="mt-4 text-xl font-semibold">JobMarket — Recruitment portal</h3><p className="mt-3 text-sm leading-7 text-slate-400">A job portal concept built around job discovery and recruitment workflows, using Angular and Firebase.</p><Link href="https://github.com/sundalsujal92/JobMarket" target="_blank" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-blue-300">View repository <ArrowUpRight size={15}/></Link></div>
            </div>
            <div className="panel overflow-hidden">
              <div className="grid-bg flex h-52 items-center justify-center bg-[#17132e] p-8"><div className="w-full max-w-sm rounded-xl border border-violet-200/20 bg-[#0c1020] p-5"><div className="flex items-center gap-2"><span className="h-7 w-7 rounded-lg bg-violet-400/20"/><span className="text-xs font-semibold">Recruitment assistant</span></div><div className="mt-5 rounded-xl bg-violet-400/10 p-3 text-xs text-violet-100">How can I help you find the right candidate?</div><div className="mt-3 ml-auto w-2/3 rounded-xl bg-blue-400/15 p-3 text-right text-xs text-blue-100">I need help tracking applications.</div><div className="mt-4 h-8 rounded-lg border border-white/10"/></div></div>
              <div className="p-7"><span className="eyebrow">Demo concept</span><h3 className="mt-4 text-xl font-semibold">AI Recruitment Assistant</h3><p className="mt-3 text-sm leading-7 text-slate-400">A proposed workflow concept for candidate enquiries, lead capture and application updates. Not yet presented as a client deployment.</p><Link href="/contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-blue-300">Discuss a similar solution <ArrowUpRight size={15}/></Link></div>
            </div>
          </div>
          <div className="mt-7 text-center"><Link href="/work" className="btn-secondary">View portfolio <ArrowRight size={16}/></Link></div>
        </div>
      </section>

      <section className="section border-y border-white/10 bg-[#0b1220]">
        <div className="container">
          <SectionHeading eyebrow="How we work" title="A simple, collaborative process." centered/>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map(([num,title,text])=><div key={num} className="border-t border-blue-300/30 pt-5"><span className="text-xs font-bold tracking-widest text-blue-300">{num}</span><h3 className="mt-5 text-xl font-semibold">{title}</h3><p className="mt-3 text-sm leading-7 text-slate-400">{text}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="panel relative overflow-hidden px-7 py-14 text-center sm:px-14">
            <div className="glow absolute inset-0"/>
            <div className="relative"><span className="eyebrow">Have a project in mind?</span><h2 className="mx-auto mt-5 max-w-2xl text-3xl font-semibold tracking-[-.04em] sm:text-5xl">Let&apos;s build something that moves you forward.</h2><p className="mx-auto mt-5 max-w-xl text-sm leading-7 text-slate-400">Share the challenge, the idea or the opportunity. We&apos;ll help you work out a practical next step.</p><Link href="/contact" className="btn-primary mt-8">Start a conversation <ArrowUpRight size={16}/></Link></div>
          </div>
        </div>
      </section>
    </>
  );
}
