import type { Metadata } from "next";
import { Mail, MessageSquare, Clock3 } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

export const metadata: Metadata = { title: "Contact", description: "Contact Sujal Digital Labs to discuss your website, automation or software project." };

export default function ContactPage() {
  return <section className="relative overflow-hidden py-20 sm:py-28"><div className="glow absolute -right-20 top-0 h-[550px] w-[700px]"/><div className="container relative"><span className="eyebrow">Start a conversation</span><h1 className="mt-6 max-w-3xl text-5xl font-semibold tracking-[-.055em] sm:text-6xl">Tell us what you&apos;re <span className="gradient-text">building.</span></h1><p className="mt-6 max-w-2xl text-lg leading-8 text-slate-400">Share a little about your business, idea or challenge. We&apos;ll review your message and get back to you.</p>
    <div className="mt-14 grid gap-10 lg:grid-cols-[.75fr_1.25fr]">
      <aside className="space-y-4">
        <div className="panel p-6"><Mail className="text-blue-300" size={21}/><h2 className="mt-4 font-semibold">Email</h2><a href="mailto:hello@sujaldigitallabs.com" className="mt-2 block text-sm text-slate-400 hover:text-white">hello@sujaldigitallabs.com</a></div>
        <div className="panel p-6"><MessageSquare className="text-blue-300" size={21}/><h2 className="mt-4 font-semibold">What to include</h2><p className="mt-2 text-sm leading-7 text-slate-400">Your goals, the problem you want to solve, expected timeline and any budget guidance you can share.</p></div>
        <div className="panel p-6"><Clock3 className="text-blue-300" size={21}/><h2 className="mt-4 font-semibold">What happens next?</h2><p className="mt-2 text-sm leading-7 text-slate-400">We&apos;ll review your enquiry and, if it looks like a fit, arrange a discovery conversation.</p></div>
      </aside>
      <ContactForm />
    </div></div></section>;
}
