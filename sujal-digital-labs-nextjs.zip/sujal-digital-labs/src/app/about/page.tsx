import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Compass, Lightbulb, ShieldCheck, Wrench } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

export const metadata: Metadata = { title: "About", description: "Meet Sujal Digital Labs and learn about our approach to digital solutions." };

const values = [
  { icon: Compass, title: "Purpose before technology", text: "We start by understanding the people, process and business outcome behind each project." },
  { icon: Lightbulb, title: "Practical innovation", text: "We use modern tools where they create genuine value, not simply because they are new." },
  { icon: ShieldCheck, title: "Trust through clarity", text: "Clear scope, honest communication and realistic expectations guide our work." },
  { icon: Wrench, title: "Care in the details", text: "We value maintainable code, thoughtful experiences and a responsible handover." },
];

export default function AboutPage() {
  return <><section className="relative overflow-hidden border-b border-white/10"><div className="glow absolute -right-20 -top-20 h-[500px] w-[700px]"/><div className="container relative py-24 sm:py-32"><span className="eyebrow">About Sujal Digital Labs</span><h1 className="mt-6 max-w-3xl text-5xl font-semibold tracking-[-.055em] sm:text-6xl">Small studio mindset. <span className="gradient-text">Big-picture thinking.</span></h1><p className="mt-7 max-w-2xl text-lg leading-8 text-slate-400">Sujal Digital Labs is an independent digital solutions studio focused on building useful software, connected workflows and thoughtful online experiences for growing businesses.</p></div></section>
    <section className="section"><div className="container grid gap-14 lg:grid-cols-[.8fr_1.2fr]"><div><SectionHeading eyebrow="Our perspective" title="Technology should make progress easier."/><p className="text-sm leading-8 text-slate-400">We believe strong digital work begins with listening. Every business has different users, constraints and ambitions. Our role is to understand those details and shape a solution that fits.</p></div><div className="grid gap-4 sm:grid-cols-2">{values.map(({icon:Icon,title,text})=><div key={title} className="panel p-6"><Icon size={22} className="text-blue-300"/><h3 className="mt-5 font-semibold">{title}</h3><p className="mt-3 text-sm leading-7 text-slate-400">{text}</p></div>)}</div></div></section>
    <section className="border-y border-white/10 bg-[#0b1220] py-20"><div className="container"><SectionHeading centered eyebrow="Founder-led collaboration" title="Direct communication, thoughtful execution." description="Sujal Digital Labs is currently a founder-led studio. You work directly with the person shaping and delivering your project, with specialist support brought in only when a project needs it."/><div className="mx-auto max-w-2xl rounded-2xl border border-white/10 bg-white/[.025] p-7 text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-blue-300/20 bg-blue-400/10 text-2xl font-black text-blue-100">S</div><h3 className="mt-5 text-xl font-semibold">Sujal Kumar</h3><p className="mt-1 text-sm text-blue-300">Founder · Sujal Digital Labs</p><p className="mt-4 text-sm leading-7 text-slate-400">Focused on web technologies, software development and practical digital solutions.</p></div></div></section>
    <section className="section"><div className="container text-center"><SectionHeading centered eyebrow="Let's work together" title="Have a challenge worth solving?" description="Tell us where you want to go and what is getting in the way. Let's explore a practical solution."/><Link href="/contact" className="btn-primary">Start a conversation <ArrowUpRight size={16}/></Link></div></section></>;
}
