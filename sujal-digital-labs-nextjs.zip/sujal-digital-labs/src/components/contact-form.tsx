"use client";

import { useState } from "react";
import { ArrowUpRight, CheckCircle2 } from "lucide-react";

export function ContactForm() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") || "");
    const email = String(form.get("email") || "");
    const company = String(form.get("company") || "");
    const service = String(form.get("service") || "");
    const budget = String(form.get("budget") || "");
    const message = String(form.get("message") || "");
    const subject = encodeURIComponent(`Project enquiry from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nCompany: ${company}\nService: ${service}\nBudget: ${budget}\n\nProject details:\n${message}`);
    window.location.href = `mailto:hello@sujaldigitallabs.com?subject=${subject}&body=${body}`;
    setSent(true);
    setLoading(false);
  }

  return <div className="panel p-6 sm:p-8">
    {sent ? <div className="py-12 text-center"><CheckCircle2 size={42} className="mx-auto text-emerald-300"/><h2 className="mt-5 text-2xl font-semibold">Your email draft is ready.</h2><p className="mt-3 text-sm leading-7 text-slate-400">Your email application should open with the enquiry details. Please send the message to complete your enquiry.</p><button onClick={() => setSent(false)} className="btn-secondary mt-6">Back to form</button></div> :
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="block text-sm text-slate-300">Your name *<input required name="name" className="input mt-2" placeholder="Jane Smith"/></label>
        <label className="block text-sm text-slate-300">Work email *<input required type="email" name="email" className="input mt-2" placeholder="jane@company.com"/></label>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="block text-sm text-slate-300">Company<input name="company" className="input mt-2" placeholder="Company name"/></label>
        <label className="block text-sm text-slate-300">What do you need?<select name="service" className="input mt-2"><option>Web development</option><option>AI automation</option><option>Cloud & DevOps</option><option>Business systems</option><option>Not sure yet</option></select></label>
      </div>
      <label className="block text-sm text-slate-300">Estimated budget<select name="budget" className="input mt-2"><option>Prefer to discuss</option><option>Under ₹25,000</option><option>₹25,000–₹60,000</option><option>₹60,000–₹1,50,000</option><option>₹1,50,000+</option></select></label>
      <label className="block text-sm text-slate-300">Tell us about your project *<textarea required name="message" rows={5} className="input mt-2 resize-y" placeholder="What are you trying to achieve? What would a successful outcome look like?"/></label>
      <p className="text-xs leading-6 text-slate-500">By submitting, you agree that we may use these details to respond to your enquiry. Do not include passwords or sensitive personal information.</p>
      {error && <p role="alert" className="text-sm text-rose-300">{error}</p>}
      <button disabled={loading} className="btn-primary w-full disabled:opacity-60" type="submit">{loading ? "Preparing email..." : "Prepare enquiry email"} <ArrowUpRight size={16}/></button>
      <p className="text-center text-[11px] text-slate-500">This opens your email application; it does not silently send or store your information.</p>
    </form>}
  </div>;
}
