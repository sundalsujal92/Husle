 "use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";

const links = [
  ["Services", "/services"],
  ["Work", "/work"],
  ["About", "/about"],
  ["Contact", "/contact"],
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#080d18]/85 backdrop-blur-xl">
      <div className="container flex h-[76px] items-center justify-between">
        <Link href="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-blue-300/30 bg-gradient-to-br from-blue-500/25 to-violet-500/20 text-lg font-black text-blue-100">S</span>
          <span className="leading-tight">
            <span className="block text-[13px] font-extrabold tracking-[.12em]">SUJAL DIGITAL</span>
            <span className="block text-[10px] font-semibold tracking-[.28em] text-slate-400">LABS</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map(([label, href]) => <Link key={href} href={href} className="text-sm text-slate-300 transition hover:text-white">{label}</Link>)}
          <Link href="/contact" className="btn-primary !px-5 !py-3 text-sm">Let&apos;s talk <ArrowUpRight size={16} /></Link>
        </nav>
        <button aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)} className="rounded-lg border border-white/15 p-2 text-white md:hidden">
          {open ? <X size={21} /> : <Menu size={21} />}
        </button>
      </div>
      {open && <nav className="container flex flex-col gap-1 pb-5 md:hidden">
        {links.map(([label, href]) => <Link key={href} href={href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-3 text-slate-200 hover:bg-white/5">{label}</Link>)}
        <Link href="/contact" onClick={() => setOpen(false)} className="btn-primary mt-2">Let&apos;s talk <ArrowUpRight size={16} /></Link>
      </nav>}
    </header>
  );
}
