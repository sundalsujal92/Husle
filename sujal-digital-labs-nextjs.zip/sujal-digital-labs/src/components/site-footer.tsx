import Link from "next/link";
import { ArrowUpRight, Mail } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-[#060a12]">
      <div className="container grid gap-12 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Link href="/" className="text-sm font-extrabold tracking-[.14em]">SUJAL DIGITAL LABS</Link>
          <p className="mt-4 max-w-sm text-sm leading-7 text-slate-400">We build digital experiences and practical automation that help ambitious businesses move forward.</p>
          <p className="mt-5 text-xs font-semibold tracking-[.16em] text-blue-300">BUILD. AUTOMATE. SCALE.</p>
        </div>
        <div>
          <h3 className="text-sm font-bold text-white">Explore</h3>
          <div className="mt-4 flex flex-col gap-3 text-sm text-slate-400">
            <Link href="/services" className="hover:text-white">Services</Link>
            <Link href="/work" className="hover:text-white">Our work</Link>
            <Link href="/about" className="hover:text-white">About us</Link>
            <Link href="/contact" className="hover:text-white">Contact</Link>
          </div>
        </div>
        <div>
          <h3 className="text-sm font-bold text-white">Start a conversation</h3>
          <p className="mt-4 text-sm leading-7 text-slate-400">Tell us what you&apos;re building. We&apos;ll help you explore the right next step.</p>
          <a href="mailto:hello@sujaldigitallabs.com" className="mt-4 inline-flex items-center gap-2 text-sm text-blue-300 hover:text-white"><Mail size={16}/> hello@sujaldigitallabs.com <ArrowUpRight size={14}/></a>
        </div>
      </div>
      <div className="container flex flex-col justify-between gap-3 border-t border-white/10 py-6 text-xs text-slate-500 sm:flex-row">
        <span>© {new Date().getFullYear()} Sujal Digital Labs. All rights reserved.</span>
        <span>Independent digital solutions studio.</span>
      </div>
    </footer>
  );
}
