export function SectionHeading({ eyebrow, title, description, centered = false }: { eyebrow: string; title: string; description?: string; centered?: boolean }) {
  return (
    <div className={centered ? "mx-auto mb-14 max-w-2xl text-center" : "mb-12 max-w-2xl"}>
      <span className="eyebrow">{eyebrow}</span>
      <h2 className="mt-5 text-3xl font-semibold leading-tight tracking-[-.04em] text-white sm:text-4xl">{title}</h2>
      {description && <p className="mt-5 text-base leading-8 text-slate-400">{description}</p>}
    </div>
  );
}
